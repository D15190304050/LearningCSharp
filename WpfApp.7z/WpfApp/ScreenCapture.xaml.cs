﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Forms;
using System.Drawing;
using System.Net;
using System.Net.Sockets;
using System.Timers;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace WpfApp
{
    /// <summary>
    /// ScreenCapture.xaml 的交互逻辑
    /// </summary>
    public partial class ScreenCapture : Window
    {
        private Socket serverSocket;
        private Socket clientSocket;
        private System.Timers.Timer timer;

        public ScreenCapture()
        {
            InitializeComponent();
        }

        private void cmdScreenCapture_Click(object sender, RoutedEventArgs e)
        {
            InitializeSockets();
            InitializeTimer();
        }

        /// <summary>
        /// Convert Bitmap to BitmapImage.
        /// </summary>
        /// <param name="bitmap">The Bitmap instance that needs conversion.</param>
        /// <returns>A BitmapImage Instance converted from the specified Bitmap instance.</returns>
        private static BitmapImage BitmapToBitmapImage(Bitmap bitmap)
        {
            BitmapImage bitmapImage = new BitmapImage();
            using (MemoryStream ms = new MemoryStream())
            {
                bitmap.Save(ms, System.Drawing.Imaging.ImageFormat.Bmp);
                bitmapImage.BeginInit();
                bitmapImage.StreamSource = ms;
                bitmapImage.CacheOption = BitmapCacheOption.OnLoad;
                bitmapImage.EndInit();
                bitmapImage.Freeze();
            }
            return bitmapImage;
        }

        private void InitializeSockets()
        {
            IPAddress ip = IPAddress.Parse("172.21.228.241");
            IPEndPoint localPoint = new IPEndPoint(ip, 16845);

            serverSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            serverSocket.Bind(localPoint);
            serverSocket.Listen(5);

            clientSocket = serverSocket.Accept();
        }

        private void InitializeTimer()
        {
            timer = new System.Timers.Timer(100);
            timer.Elapsed += ElapsedHandler;
        }

        private void ElapsedHandler(object sender, ElapsedEventArgs e)
        {
            BitmapImage currentScreenCapture = GetCurrentScreenCapture();
            byte[] imageBytes = SerializeObject(currentScreenCapture);
            clientSocket.Send(imageBytes);
            clientSocket.Receive(new byte[5]);
        }

        private BitmapImage GetCurrentScreenCapture()
        {
            Bitmap bmp = new Bitmap(Screen.PrimaryScreen.Bounds.Width, Screen.PrimaryScreen.Bounds.Height);
            Graphics graphics = Graphics.FromImage(bmp);  //创建画笔
            graphics.CopyFromScreen(new System.Drawing.Point(0, 0), new System.Drawing.Point(0, 0), bmp.Size);//截屏
            BitmapImage screenCapture = BitmapToBitmapImage(bmp);
            bmp.Dispose();//关闭对象
            graphics.Dispose();//关闭画笔

            return screenCapture;
        }

        private byte[] SerializeObject(object o)
        {
            MemoryStream ms = new MemoryStream();
            //创建序列化的实例
            BinaryFormatter formatter = new BinaryFormatter();
            long size = ms.GetBuffer().Length;
            formatter.Serialize(ms, o);//序列化对象，写入ms流中  
            ms.Position = 0;
            //byte[] bytes = new byte[ms.Length];//这个有错误
            byte[] bytes = ms.GetBuffer();
            ms.Read(bytes, 0, bytes.Length);
            ms.Close();
            return bytes;
        }
    }
}

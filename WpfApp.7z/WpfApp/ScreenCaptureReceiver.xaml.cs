﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.IO;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.Runtime.Serialization.Formatters.Binary;

namespace WpfApp
{
    /// <summary>
    /// ScreenCaptureReceiver.xaml 的交互逻辑
    /// </summary>
    public partial class ScreenCaptureReceiver : Window
    {
        public ScreenCaptureReceiver()
        {
            InitializeComponent();
        }

        private void cmdScreenCapture_Click(object sender, RoutedEventArgs e)
        {
            Socket clientSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            clientSocket.Connect(IPAddress.Parse("172.21.228.241"), 16845);

            Thread thread = new Thread(() =>
            {
                byte[] receiveBuffer = new byte[10240];
                int receivedLength = clientSocket.Receive(receiveBuffer);
                clientSocket.Send(Encoding.ASCII.GetBytes("N"));
                byte[] contents = new byte[receivedLength];
                for (int i = 0; i < receivedLength; i++)
                    contents[i] = receiveBuffer[i];
                object o = DeserializeObject(contents);
                BitmapImage currentServerScreen = o as BitmapImage;
                if (currentServerScreen != null)
                    imgScreenCapture.Source = currentServerScreen;
            });
        }

        public static object DeserializeObject(byte[] bytes)
        {
            object o = null;
            if (bytes == null)
                return o;
            //利用传来的byte[]创建一个内存流
            MemoryStream ms = new MemoryStream(bytes);
            ms.Position = 0;
            BinaryFormatter formatter = new BinaryFormatter();
            o = formatter.Deserialize(ms);//把内存流反序列成对象  
            ms.Close();
            return o;
        }
    }
}
